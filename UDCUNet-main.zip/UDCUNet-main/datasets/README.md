# Datasets

This folder is mainly for storing datasets used for training/validation/testing.

## Practice

1. Separate your codes and datasets. So it is better to soft link your dataset (such as DIV2K, FFHQ, *etc*) here.
    ```bash
    ln -s DATASET_PATH ./
    ```
