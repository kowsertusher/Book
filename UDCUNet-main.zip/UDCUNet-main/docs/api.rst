API
=================

basicsr.data
--------------
.. automodule:: basicsr.data
    :members:

basicsr.models
---------------
.. automodule:: basicsr.models
    :members:

basicsr.archs
--------------
.. automodule:: basicsr.archs
    :members:

basicsr.ops
--------------
.. automodule:: basicsr.ops
    :members:

basicsr.losses
--------------
.. automodule:: basicsr.losses
    :members:

basicsr.utils
--------------
.. automodule:: basicsr.utils
    :members:

basicsr.metrics
--------------
.. automodule:: basicsr.metrics
    :members:

basicsr.train & test
--------------
.. automodule:: basicsr.train
    :members:

.. automodule:: basicsr.test
    :members:
