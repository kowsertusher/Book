Welcome to BasicSR's documentation!
===================================

.. toctree::
   :maxdepth: 3
   :caption: API

   api.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
